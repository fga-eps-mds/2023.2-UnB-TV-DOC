#ifndef _MATRIX_H_
#define _MATRIX_H_

void matrix_mult(double *A, double *B, double *C, int N);

#endif