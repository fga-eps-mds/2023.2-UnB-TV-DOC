#ifndef _SUM_H_
#define _SUM_H_

long long int sum(int *v, long long int N);

#endif
