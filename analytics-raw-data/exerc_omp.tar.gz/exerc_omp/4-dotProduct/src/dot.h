#ifndef _DOT_H_
#define _DOT_H_

double dot_product(double *a, double *b, long long int N);

#endif